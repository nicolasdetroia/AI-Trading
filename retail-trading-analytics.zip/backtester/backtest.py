import pandas as pd

def backtest_strategy(csv_file, strategy_fn):
    df = pd.read_csv(csv_file)
    df['Signal'] = df.apply(strategy_fn, axis=1)

    balance = 10000
    position = 0
    for i, row in df.iterrows():
        if row['Signal'] == 'buy' and balance > 0:
            position = balance / row['Close']
            balance = 0
        elif row['Signal'] == 'sell' and position > 0:
            balance = position * row['Close']
            position = 0
    final_balance = balance + position * df.iloc[-1]['Close']
    return {
        'initial': 10000,
        'final': round(final_balance, 2),
        'return_%': round((final_balance - 10000) / 100, 2)
    }

# Example strategy
def example_strategy(row):
    if row['RSI'] < 30:
        return 'buy'
    elif row['RSI'] > 70:
        return 'sell'
    return 'hold'
