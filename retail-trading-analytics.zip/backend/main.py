from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import requests

app = FastAPI()
FINNHUB_API_KEY = "your_finnhub_api_key"

class SymbolRequest(BaseModel):
    symbol: str

@app.post("/signal/rsi")
def get_rsi_signal(data: SymbolRequest):
    url = f"https://finnhub.io/api/v1/indicator?symbol={data.symbol}&resolution=D&indicator=rsi&timeperiod=14&token={FINNHUB_API_KEY}"
    response = requests.get(url)
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="Error fetching RSI data")
    rsi_value = response.json().get("rsi", [])[0]
    signal = "buy" if rsi_value < 30 else "sell" if rsi_value > 70 else "hold"
    return {"rsi": rsi_value, "signal": signal}

@app.post("/signal/volume_spike")
def get_volume_signal(data: SymbolRequest):
    url = f"https://finnhub.io/api/v1/stock/candle?symbol={data.symbol}&resolution=D&count=20&token={FINNHUB_API_KEY}"
    response = requests.get(url)
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="Error fetching volume data")

    json = response.json()
    if 'v' not in json:
        raise HTTPException(status_code=400, detail="Volume data missing")

    volumes = json["v"]
    latest = volumes[-1]
    avg = sum(volumes[:-1]) / (len(volumes) - 1)

    signal = "volume spike" if latest > 1.5 * avg else "normal"
    return {"latest_volume": latest, "avg_volume": avg, "signal": signal}

@app.post("/signal/ma_crossover")
def get_ma_crossover(data: SymbolRequest):
    url = f"https://finnhub.io/api/v1/indicator?symbol={data.symbol}&resolution=D&indicator=sma&timeperiod=5&token={FINNHUB_API_KEY}"
    short_term = requests.get(url).json().get("sma", [])
    url2 = f"https://finnhub.io/api/v1/indicator?symbol={data.symbol}&resolution=D&indicator=sma&timeperiod=20&token={FINNHUB_API_KEY}"
    long_term = requests.get(url2).json().get("sma", [])

    if not short_term or not long_term:
        raise HTTPException(status_code=400, detail="MA data missing")

    crossover = "bullish" if short_term[-1] > long_term[-1] else "bearish" if short_term[-1] < long_term[-1] else "neutral"
    return {
        "sma_5": short_term[-1],
        "sma_20": long_term[-1],
        "signal": crossover
    }
