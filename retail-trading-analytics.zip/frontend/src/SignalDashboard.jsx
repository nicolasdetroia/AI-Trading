import React, { useState } from 'react';
import axios from 'axios';

export default function SignalDashboard() {
  const [symbol, setSymbol] = useState('');
  const [result, setResult] = useState({});

  const fetchAllSignals = async () => {
    if (!symbol) return alert("Please enter a symbol");
    const endpoints = ['rsi', 'volume_spike', 'ma_crossover'];
    const signals = {};
    try {
      for (let endpoint of endpoints) {
        const res = await axios.post(`/signal/${endpoint}`, { symbol });
        signals[endpoint] = res.data;
      }
      setResult(signals);
    } catch (e) {
      alert("Error fetching signals");
    }
  };

  return (
    <div className="p-6 max-w-xl mx-auto bg-white rounded-xl shadow-md mt-10">
      <h2 className="text-xl font-bold mb-4">Signal Dashboard</h2>
      <input
        type="text"
        value={symbol}
        onChange={(e) => setSymbol(e.target.value.toUpperCase())}
        className="border p-2 w-full"
        placeholder="Enter stock symbol"
      />
      <button
        onClick={fetchAllSignals}
        className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
      >
        Get All Signals
      </button>

      {result.rsi && (
        <div className="mt-4 space-y-2">
          <p><strong>RSI:</strong> {result.rsi.rsi} → <strong>{result.rsi.signal.toUpperCase()}</strong></p>
          <p><strong>Volume Spike:</strong> {result.volume_spike.signal}</p>
          <p><strong>MA Crossover:</strong> {result.ma_crossover.signal}</p>
        </div>
      )}
    </div>
  );
}
