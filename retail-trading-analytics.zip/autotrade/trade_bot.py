import alpaca_trade_api as tradeapi

API_KEY = 'your_key'
SECRET_KEY = 'your_secret'
BASE_URL = 'https://paper-api.alpaca.markets'

api = tradeapi.REST(API_KEY, SECRET_KEY, BASE_URL, api_version='v2')

def trade(symbol, signal):
    if signal == 'buy':
        api.submit_order(symbol=symbol, qty=1, side='buy', type='market', time_in_force='gtc')
    elif signal == 'sell':
        api.submit_order(symbol=symbol, qty=1, side='sell', type='market', time_in_force='gtc')
